//
//  JCLinePointData.h
//  JCLineChartViewDemo
//
//  Created by ThreegeneDev on 14-8-12.
//  Copyright (c) 2014年 JimpleChen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCLinePointData : NSObject

@end
