//
//  JCLinePointData.m
//  JCLineChartViewDemo
//
//  Created by ThreegeneDev on 14-8-12.
//  Copyright (c) 2014年 JimpleChen. All rights reserved.
//

#import "JCLinePointData.h"

@implementation JCLinePointData

@end
